-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 30, 2018 at 09:17 AM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `license`
--

-- --------------------------------------------------------

--
-- Table structure for table `registeruser`
--

CREATE TABLE IF NOT EXISTS `registeruser` (
  `id_user` int(5) NOT NULL AUTO_INCREMENT,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `level` enum('admin','user') NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `registeruser`
--

INSERT INTO `registeruser` (`id_user`, `username`, `password`, `level`) VALUES
(7, 'administrator', 'ps20160981', 'user'),
(8, 'administrator', 'gs20161359', 'admin'),
(10, 'administrator', 'staff', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `tb_carsarrived`
--

CREATE TABLE IF NOT EXISTS `tb_carsarrived` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plate` varchar(20) NOT NULL,
  `dateArrived` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `tb_carsarrived`
--

INSERT INTO `tb_carsarrived` (`id`, `plate`, `dateArrived`) VALUES
(1, 'RAA213', '2018-07-25 09:58:40'),
(2, 'RAA213', '2018-07-25 09:59:16'),
(3, 'RAA213', '2018-07-25 10:00:36'),
(4, 'RAA213', '2018-07-25 10:00:55'),
(5, 'RAA213', '2018-07-25 10:01:17'),
(6, 'RAD211A', '2018-07-25 10:01:32'),
(7, 'RAB686A', '2018-07-25 10:26:38'),
(8, 'RAB686A', '2018-07-25 10:32:19'),
(9, 'RAD211A', '2018-07-25 10:35:03'),
(10, 'RAB686A', '2018-07-25 10:36:01'),
(11, 'RAB686A', '2018-07-25 10:36:54'),
(12, 'RAB686A', '2018-07-25 10:39:28'),
(13, 'RAB686A', '2018-07-25 10:42:10'),
(14, 'RAB686A', '2018-07-25 10:44:02'),
(15, 'RAB686A', '2018-07-25 10:45:14'),
(16, 'RAB686A', '2018-07-25 11:12:37'),
(17, 'RAA121I', '2018-07-25 11:14:28'),
(18, 'RAB686A', '2018-07-25 11:15:36'),
(19, 'RAB686A', '2018-07-25 11:16:06'),
(20, 'RAB686A', '2018-07-25 17:25:00'),
(21, 'RAB686A', '2018-07-25 17:25:42'),
(22, 'RAB686A', '2018-07-25 18:48:57'),
(23, 'RAC900F', '2018-07-25 18:50:48'),
(24, 'RAC900F', '2018-07-25 18:57:05'),
(25, 'RAC900F', '2018-07-25 19:02:58'),
(26, 'RAA213', '2018-07-26 14:33:39'),
(27, 'RAC900F', '2018-07-26 17:10:41'),
(28, 'MCLRNF1', '2018-07-26 17:14:03'),
(29, 'RAC900F', '2018-07-29 12:21:34');

-- --------------------------------------------------------

--
-- Table structure for table `tb_lincense`
--

CREATE TABLE IF NOT EXISTS `tb_lincense` (
  `plate` varchar(25) NOT NULL,
  `fname` text NOT NULL,
  `lname` text NOT NULL,
  `address` text NOT NULL,
  `email` varchar(25) NOT NULL,
  `category` varchar(25) NOT NULL,
  `contact` int(15) NOT NULL,
  PRIMARY KEY (`plate`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tb_lincense`
--

INSERT INTO `tb_lincense` (`plate`, `fname`, `lname`, `address`, `email`, `category`, `contact`) VALUES
('RAB686A', 'Tuyambaze', 'Innocent', 'Nyarugrnge', 'tuyinnocent@hotmail.com', 'student', 739821707),
('RAA001B', 'Tuyambaze', 'Innocent', 'Gisenyi', 'tuyinnocent@hotmail.com', 'staff', 739821707),
('RAD211A', 'Kamana', 'patrick', 'cyangugu', 'Sarah@gmail.com', 'staff', 785728558);
